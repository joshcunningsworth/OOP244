/*
map.h
Author: Josh Cunningham
*/
//#pragma once
const int MAPL=20;
const int MAPW=30;
